# IFT-Bayeisan-Analysis
